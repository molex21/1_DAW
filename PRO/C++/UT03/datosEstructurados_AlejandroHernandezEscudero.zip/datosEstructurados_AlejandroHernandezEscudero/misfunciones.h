#include "misfunciones.cpp"
#include <stdio.h>
#include <conio.h>
#include <iostream>
using namespace std;


void familiasInputs(familia *familiaActual);
void familiasDisplay(familia *familiaActualDisplay, char *letraFamilia);