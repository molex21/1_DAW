#include "practica3_2_alejandrohernandez.cpp"


int contarLineas(string nombreFicheroEntrada);

void buscarEnFichero(string nombreFicheroEntrada);

void generarFichero(string nombreFicheroEntrada , string nombreFicheroSalida);

