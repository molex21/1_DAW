

// utilizo este fichero para partir el codigo, es util cuando queremos que varias personas trabajen sobre el mismo codigo

int resta(int a, int b)
{
    return (a - b);
}