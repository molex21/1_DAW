
/* utilidades.h */

/* En los fichero de cabecera solo van las declaraciones de las funciones que queremos se usen de nuestra libreria*/

int multiplica(int a, int b)
{
   return (a * b);
}